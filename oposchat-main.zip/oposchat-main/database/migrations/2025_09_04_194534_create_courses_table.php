<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('courses', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('exam_type')->nullable(); // SAT, GRE, GMAT, etc.
            $table->string('icon')->nullable(); // emoji or icon
            $table->string('color')->nullable(); // gradient colors
            $table->string('badge')->nullable(); // POPULAR, ADVANCED, etc.
            $table->string('badge_color')->nullable();
            $table->text('full_description')->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('courses');
    }
};
