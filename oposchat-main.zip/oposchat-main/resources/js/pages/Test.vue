<template>
  <div class="flex items-center justify-center min-h-screen bg-gray-100">
    <div class="bg-white p-8 rounded-2xl shadow-md text-center w-full max-w-md">
      <h1 class="text-2xl font-bold text-blue-600 mb-4">Hello from Test.vue 🎉</h1>
      <p class="text-gray-600">This page is rendered with Inertia + Vue + Laravel.</p>
    </div>
  </div>
</template>

<script setup>
// You can add props or logic here later
</script>

<style scoped>
/* optional extra styles */
</style>
