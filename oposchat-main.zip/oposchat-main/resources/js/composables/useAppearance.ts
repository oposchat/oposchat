import { onMounted, ref } from 'vue';

type Appearance = 'light' | 'dark';

export function updateTheme(value: Appearance) {
    if (typeof window === 'undefined') {
        return;
    }

    document.documentElement.classList.toggle('dark', value === 'dark');
    document.documentElement.style.colorScheme = value;
}

const setCookie = (name: string, value: string, days = 365) => {
    if (typeof document === 'undefined') {
        return;
    }

    const maxAge = days * 24 * 60 * 60;

    document.cookie = `${name}=${value};path=/;max-age=${maxAge};SameSite=Lax`;
};

const mediaQuery = () => {
    if (typeof window === 'undefined') {
        return null;
    }

    return window.matchMedia('(prefers-color-scheme: dark)');
};

const getStoredAppearance = () => {
    if (typeof window === 'undefined') {
        return null;
    }

    return localStorage.getItem('appearance') as Appearance | null;
};

const handleSystemThemeChange = () => {
    const currentAppearance = getStoredAppearance();

    updateTheme(currentAppearance || 'light');
};

export function initializeTheme() {
    if (typeof window === 'undefined') {
        return;
    }

    // Initialize theme from saved preference or default to light...
    const savedAppearance = getStoredAppearance();
    updateTheme(savedAppearance || 'light');
}

// Initialize the shared appearance ref from localStorage (if available)
// This ensures reactive state matches the actual theme applied to the document
// so the first click on the toggle behaves as expected.
const appearance = ref<Appearance>(getStoredAppearance() || 'light');

export function useAppearance() {
    onMounted(() => {
        // Ensure the theme is applied based on the current appearance value
        // and sync the appearance ref with what's actually stored
        const storedAppearance = getStoredAppearance();
        if (storedAppearance) {
            appearance.value = storedAppearance;
        }
        updateTheme(appearance.value);
    });

    function updateAppearance(value: Appearance) {
        appearance.value = value;

        // Store in localStorage for client-side persistence...
        localStorage.setItem('appearance', value);

        // Store in cookie for SSR...
        setCookie('appearance', value);

        updateTheme(value);
    }

    return {
        appearance,
        updateAppearance,
    };
}
