<script setup lang="ts">
import { computed, ref, watch, nextTick, onMounted } from 'vue';
import { User, Bot, Copy, ThumbsUp, ThumbsDown, Square, Maximize2, X } from 'lucide-vue-next';
import { Button } from '@/components/ui/button';
import DOMPurify from 'dompurify';
import { marked } from 'marked';
import { useToast } from '@/composables/useToast';
import mermaid from 'mermaid';

interface Props {
    message: {
        id: string;
        content: string;
        role: 'user' | 'assistant';
        timestamp: string;
        isStreaming?: boolean;
        streamingContent?: string;
        sessionId?: string;
    };
    onStopStreaming?: (sessionId: string) => void;
}

const props = defineProps<Props>();

// Toast composable
const { success } = useToast();

// Template ref for the prose content area
const proseRef = ref<HTMLElement | null>(null);

// Use marked for GFM (tables) and DOMPurify to sanitize output
marked.setOptions({ gfm: true, breaks: true });

const isUser = computed(() => props.message.role === 'user');
const isStreaming = computed(() => props.message.isStreaming || false);
const hasStreamingContent = computed(() => props.message.streamingContent && props.message.streamingContent !== props.message.content);

const copyMessage = async () => {
    try {
        if (!proseRef.value) {
            console.error('No content to copy');
            return;
        }

        // Get both HTML and text content from the rendered message
        const htmlContent = proseRef.value.innerHTML || '';
        const textContent = proseRef.value.innerText || proseRef.value.textContent || '';
        
        if (!htmlContent && !textContent) {
            console.error('No content to copy');
            return;
        }

        // Copy with formatting (HTML) and plain text fallback
        // This allows pasting into Word with formatting preserved
        await navigator.clipboard.write([
            new ClipboardItem({
                'text/html': new Blob([htmlContent], { type: 'text/html' }),
                'text/plain': new Blob([textContent], { type: 'text/plain' })
            })
        ]);

        // Show success toast
        success('Copied to clipboard');
    } catch (err) {
        console.error('Failed to copy:', err);
        // Fallback to plain text if ClipboardItem fails
        try {
            const textContent = proseRef.value?.innerText || proseRef.value?.textContent || '';
            await navigator.clipboard.writeText(textContent);
            success('Copied to clipboard');
        } catch (fallbackErr) {
            console.error('Fallback copy also failed:', fallbackErr);
        }
    }
};

const stopStreaming = () => {
    if (props.message.sessionId && props.onStopStreaming) {
        props.onStopStreaming(props.message.sessionId);
    }
};


// Process LaTeX/math notation
const processMathNotation = (content) => {
    // Process display math (block math) - \[ ... \]
    content = content.replace(/\\\[([\s\S]*?)\\\]/g, (match, mathContent) => {
        return `<div class="my-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border-l-4 border-blue-500">
            <div class="text-center font-mono text-lg">
                ${mathContent.trim()}
            </div>
        </div>`;
    });

    // Process inline math - \( ... \)
    content = content.replace(/\\\(([\s\S]*?)\\\)/g, (match, mathContent) => {
        return `<span class="inline-math font-mono bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-sm">
            ${mathContent.trim()}
        </span>`;
    });

    // Process simple math expressions without LaTeX delimiters
    // Look for patterns like "π × r²" or "3.14 × 49"
    content = content.replace(/([π])\s*×\s*([a-zA-Z0-9²³⁴⁵⁶⁷⁸⁹]+)/g, (match, symbol, expression) => {
        return `<span class="inline-math font-mono bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-sm">
            ${symbol} × ${expression}
        </span>`;
    });

    // Process superscripts (like r², x³)
    content = content.replace(/([a-zA-Z0-9]+)([²³⁴⁵⁶⁷⁸⁹]+)/g, (match, base, superscript) => {
        return `<span class="inline-math">${base}<sup class="text-xs">${superscript}</sup></span>`;
    });

    // Process LaTeX fractions (\frac{numerator}{denominator})
    content = content.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, (match, numerator, denominator) => {
        return `<span class="inline-math font-mono bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-sm">
            <span class="inline-block align-middle">
                <span class="block text-center border-b border-gray-400">${numerator}</span>
                <span class="block text-center">${denominator}</span>
            </span>
        </span>`;
    });

    // Process simple fractions (like 14/2)
    content = content.replace(/(\d+)\/(\d+)/g, (match, numerator, denominator) => {
        return `<span class="inline-math font-mono bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-sm">
            <span class="inline-block align-middle">
                <span class="block text-center border-b border-gray-400">${numerator}</span>
                <span class="block text-center">${denominator}</span>
            </span>
        </span>`;
    });

    // Process LaTeX text commands (\text{...})
    content = content.replace(/\\text\{([^}]+)\}/g, (match, text) => {
        return `<span class="font-normal">${text}</span>`;
    });

    // Process LaTeX times symbol (\times)
    content = content.replace(/\\times/g, '×');

    // Process LaTeX sqrt symbol
    content = content.replace(/\\sqrt\{([^}]+)\}/g, (match, expression) => {
        return `<span class="inline-math">√${expression}</span>`;
    });

    // Process LaTeX pm symbol (±)
    content = content.replace(/\\pm/g, '±');

    return content;
};





// Decode HTML entities
const decodeHtml = (html: string): string => {
    const txt = document.createElement('textarea');
    txt.innerHTML = html;
    return txt.value;
};

// Format content with markdown-like formatting and sanitize output.
// `applyHeuristics` toggles heading/list heuristics (disable while streaming)
// Process list-like content that doesn't have proper markdown syntax
const processListLikeContent = (content: string): string => {
    // Look for patterns like "Topic 1", "Description:", "Examples:" that should be formatted as lists
    const lines = content.split('\n');
    const processedLines = [];
    let inList = false;
    let listItems = [];
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        
        // Check if this looks like a list item (Topic X, Description:, Examples:, etc.)
        const isListItem = /^(Topic \d+|Description:|Examples?:?)$/i.test(line);
        
        if (isListItem) {
            if (!inList) {
                // Start a new list
                inList = true;
                listItems = [];
            }
            listItems.push(line);
        } else {
            // If we were in a list and now we're not, process the accumulated list
            if (inList && listItems.length > 0) {
                processedLines.push('- ' + listItems.join('\n- '));
                inList = false;
                listItems = [];
            }
            processedLines.push(line);
        }
    }
    
    // Handle any remaining list items
    if (inList && listItems.length > 0) {
        processedLines.push('- ' + listItems.join('\n- '));
    }
    
    return processedLines.join('\n');
};

const formatContent = (content: string | undefined, applyHeuristics = true): string => {
    if (!content) return '';

    // First, decode any HTML entities so we can detect raw HTML tables
    const decodedContent = decodeHtml(content);

    // If the decoded content contains an HTML table tag, treat it as HTML.
    if (decodedContent.includes('<table')) {
        // Sanitize the decoded HTML, then apply our table styling wrapper.
    let sanitized = String(DOMPurify.sanitize(decodedContent, { USE_PROFILES: { html: true } }) as unknown as string);

        sanitized = sanitized.replace(/<table/g, '<div class="overflow-x-auto my-6">$&');
        sanitized = sanitized.replace(/<\/table>/g, '</table></div>');

        // Ensure table elements take full width: add `w-full` class when missing
        sanitized = sanitized.replace(/<table([^>]*)class=(["'])(.*?)\2([^>]*)>/g, (m, before, quote, cls, after) => {
            return `<table${before}class=${quote}${cls} w-full${quote}${after}>`;
        });
        sanitized = sanitized.replace(/<table(?![^>]*class=)/g, '<table class="w-full"');

        // Ensure lists show bullets even if global reset removed them
        sanitized = sanitized.replace(/<ul([^>]*)class=(["'])(.*?)\2([^>]*)>/g, (m, before, quote, cls, after) => {
            // append list-disc and pl-6 ml-4 for proper indentation
            const newCls = (cls + ' list-disc pl-6 ml-4').replace(/\s+/g, ' ').trim();
            return `<ul${before}class=${quote}${newCls}${quote}${after}>`;
        });
        sanitized = sanitized.replace(/<ul(?![^>]*class=)/g, '<ul class="list-disc pl-6 ml-4"');
        sanitized = sanitized.replace(/<ol([^>]*)class=(["'])(.*?)\2([^>]*)>/g, (m, before, quote, cls, after) => {
            const newCls = (cls + ' list-decimal pl-6 ml-4').replace(/\s+/g, ' ').trim();
            return `<ol${before}class=${quote}${newCls}${quote}${after}>`;
        });
        sanitized = sanitized.replace(/<ol(?![^>]*class=)/g, '<ol class="list-decimal pl-6 ml-4"');

        // Add classes to th/td
        sanitized = sanitized.replace(/<th>/g, '<th class="border border-gray-300 dark:border-gray-600 px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-gray-100 bg-gray-50 dark:bg-gray-800">');
        sanitized = sanitized.replace(/<td>/g, '<td class="border border-gray-300 dark:border-gray-600 px-4 py-3 text-sm text-gray-900 dark:text-gray-100">');

        // Heuristic: convert paragraph headings ending with ':' into proper headings
        // when followed by a list or standalone paragraph heading.
        if (applyHeuristics) {
            sanitized = sanitized.replace(/<p>\s*([^<]{2,200}?)\s*:\s*<\/p>\s*(?=<(ul|ol)>)/g, '<h2>$1</h2>');
            sanitized = sanitized.replace(/<p>\s*([^<]{2,200}?)\s*:\s*<\/p>/g, '<h2>$1</h2>');

            // Convert an opening list item that is just a heading ("Heading:") into a heading
            sanitized = sanitized.replace(/<(ul|ol)>\s*<li>\s*([^<]{2,200}?)\s*:\s*<\/li>\s*/g, '<h3>$2</h3><$1>');
        }

        return sanitized;
    }

    // Otherwise treat as markdown (supports tables via GFM)
    let text = content;

    // Process LaTeX/math notation first
    text = processMathNotation(text);

    // Process list-like content that doesn't have proper markdown syntax
    text = processListLikeContent(text);

    // Render markdown to HTML (marked supports GFM tables)
    const html = marked.parse(text || '', { gfm: true });

    // Sanitize rendered HTML and style tables
    let sanitized = String(DOMPurify.sanitize(html, { USE_PROFILES: { html: true } }) as unknown as string);

    sanitized = sanitized.replace(/<table/g, '<div class="overflow-x-auto my-6">$&');
    sanitized = sanitized.replace(/<\/table>/g, '</table></div>');
    // Ensure table elements take full width: add `w-full` class when missing
    sanitized = sanitized.replace(/<table([^>]*)class=(["'])(.*?)\2([^>]*)>/g, (m, before, quote, cls, after) => {
        return `<table${before}class=${quote}${cls} w-full${quote}${after}>`;
    });
    sanitized = sanitized.replace(/<table(?![^>]*class=)/g, '<table class="w-full"');
    sanitized = sanitized.replace(/<th>/g, '<th class="border border-gray-300 dark:border-gray-600 px-4 py-3 text-left text-sm font-semibold text-gray-900 dark:text-gray-100 bg-gray-50 dark:bg-gray-800">');
    sanitized = sanitized.replace(/<td>/g, '<td class="border border-gray-300 dark:border-gray-600 px-4 py-3 text-sm text-gray-900 dark:text-gray-100">');

    // Ensure lists show bullets (Tailwind reset may remove default markers)
    sanitized = sanitized.replace(/<ul([^>]*)class=(["'])(.*?)\2([^>]*)>/g, (m, before, quote, cls, after) => {
        const newCls = (cls + ' list-disc pl-6 ml-4').replace(/\s+/g, ' ').trim();
        return `<ul${before}class=${quote}${newCls}${quote}${after}>`;
    });
    sanitized = sanitized.replace(/<ul(?![^>]*class=)/g, '<ul class="list-disc pl-6 ml-4"');
    sanitized = sanitized.replace(/<ol([^>]*)class=(["'])(.*?)\2([^>]*)>/g, (m, before, quote, cls, after) => {
        const newCls = (cls + ' list-decimal pl-6 ml-4').replace(/\s+/g, ' ').trim();
        return `<ol${before}class=${quote}${newCls}${quote}${after}>`;
    });
    sanitized = sanitized.replace(/<ol(?![^>]*class=)/g, '<ol class="list-decimal pl-6 ml-4"');

    // Heuristic: convert paragraph headings ending with ':' into proper headings
    if (applyHeuristics) {
        sanitized = sanitized.replace(/<p>\s*([^<]{2,200}?)\s*:\s*<\/p>\s*(?=<(ul|ol)>)/g, '<h2>$1</h2>');
        sanitized = sanitized.replace(/<p>\s*([^<]{2,200}?)\s*:\s*<\/p>/g, '<h2>$1</h2>');
        sanitized = sanitized.replace(/<(ul|ol)>\s*<li>\s*([^<]{2,200}?)\s*:\s*<\/li>\s*/g, '<h3>$2</h3><$1>');

        // Promote lines like "Topic 1" to H2 when followed by a Description label
        sanitized = sanitized.replace(/<p>\s*(Topic\s+\d[\w\s\-:\.]*)\s*<\/p>\s*(?=<p>\s*Description:)/gi, '<h2>$1</h2>');

        // Bold the Description label and keep its content inline
        sanitized = sanitized.replace(/<p>\s*Description:\s*(.*?)\s*<\/p>/gi, '<p><strong>Description:</strong> $1</p>');

        // Convert Examples: + consecutive <p> lines into a list
        const examplesLabel = /<p>\s*Examples:\s*<\/p>/i;
        let exIdx = sanitized.search(examplesLabel);
        while (exIdx !== -1) {
            const labelMatch = sanitized.match(examplesLabel);
            if (!labelMatch) break;
            const startPos = sanitized.indexOf(labelMatch[0], exIdx);
            let cursor = startPos + labelMatch[0].length;
            const itemRe = /^\s*<p>\s*([\s\S]*?)\s*<\/p>/i;
            const items: string[] = [];
            while (true) {
                const rest = sanitized.slice(cursor);
                const m = rest.match(itemRe);
                if (!m) break;
                const text = m[1].trim();
                // stop if next paragraph looks like a labeled section or another heading
                if (/^([A-Z][A-Za-z0-9\s]{0,80}:)$/.test(text) || /^Topic\s+\d+/i.test(text)) break;
                items.push(text);
                cursor += m[0].length;
            }
            if (items.length > 0) {
                const seqRe = new RegExp(labelMatch[0].replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?:\s*<p>\s*[\s\S]*?\s*<\/p>){' + items.length + '}', 'i');
                const ul = '<p><strong>Examples:</strong></p><ul>' + items.map(i => '<li>' + i + '</li>').join('') + '</ul>';
                sanitized = sanitized.replace(seqRe, ul);
        } else {
                break;
            }
            exIdx = sanitized.search(examplesLabel);
        }
    }

    // Process Mermaid diagrams - detect and wrap in proper format
    sanitized = processMermaidDiagrams(sanitized);
    
    return sanitized;
};

// Normalize and sanitize Mermaid text: decode entities, strip tags, normalize newlines,
// and drop trailing narrative/explanation lines that aren't valid Mermaid syntax.
const sanitizeMermaidText = (code: string): string => {
    if (!code) return '';
    // Decode common HTML entities first
    let text = code
        .replace(/&gt;/g, '>')
        .replace(/&lt;/g, '<')
        .replace(/&amp;/g, '&')
        .replace(/&quot;/g, '"')
        .replace(/&#039;/g, "'");
    // Strip any residual HTML tags
    text = text.replace(/<[^>]*>/g, '');
    // Normalize CRLF to LF
    text = text.replace(/\r\n?/g, '\n');
    // Keep only contiguous Mermaid-relevant lines starting from header
    const lines = text.split('\n');
    const kept: string[] = [];
    const isHeader = (l: string) => /^(\s*)?(graph|flowchart)\b/i.test(l.trim());
    const isMermaidLine = (l: string) => {
        const t = l.trim();
        if (t === '') return true; // allow blank lines inside block
        // Allow common mermaid directives and edge definitions
        if (/^(subgraph|end|classDef|linkStyle|click|style|direction|%%)/i.test(t)) return true;
        if (t.includes('--') || t.includes('==')) return true; // edges like A --> B or A --- B or A ==> B
        return false;
    };
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (i === 0) {
            if (!isHeader(line)) return '';
            kept.push(line);
            continue;
        }
        if (isMermaidLine(line)) {
            kept.push(line);
        } else {
            break; // stop at first narrative/non-mermaid line
        }
    }
    return kept.join('\n').trim();
};

// Parse a raw Mermaid block into { mermaid, explanation }
const parseMermaidBlock = (code: string): { mermaid: string; explanation: string } => {
    if (!code) return { mermaid: '', explanation: '' };
    // Decode entities and strip tags, normalize newlines
    let text = code
        .replace(/&gt;/g, '>')
        .replace(/&lt;/g, '<')
        .replace(/&amp;/g, '&')
        .replace(/&quot;/g, '"')
        .replace(/&#039;/g, "'")
        .replace(/<[^>]*>/g, '')
        .replace(/\r\n?/g, '\n');
    const lines = text.split('\n');
    const isHeader = (l: string) => /^(\s*)?(graph|flowchart)\b/i.test(l.trim());
    const isMermaidLine = (l: string) => {
        const t = l.trim();
        if (t === '') return true;
        if (/^(subgraph|end|classDef|linkStyle|click|style|direction|%%)/i.test(t)) return true;
        if (t.includes('--') || t.includes('==')) return true;
        return false;
    };
    // Find header
    let start = -1;
    for (let i = 0; i < lines.length; i++) {
        if (isHeader(lines[i])) { start = i; break; }
    }
    if (start === -1) return { mermaid: '', explanation: text.trim() };
    let end = start + 1;
    while (end < lines.length && isMermaidLine(lines[end])) end++;
    const mermaid = lines.slice(start, end).join('\n').trim();
    const explanation = lines.slice(end).join('\n').trim();
    return { mermaid, explanation };
};

// Process and wrap Mermaid diagrams
const processMermaidDiagrams = (html: string): string => {
    // Detect Mermaid syntax patterns (with or without code blocks)
    // Look for graph/flowchart syntax followed by node definitions
    
    let uniqueIdCounter = 0;
    
    // First, check if already in code blocks
    const codeBlockRegex = /<pre><code class="language-mermaid">([\s\S]*?)<\/code><\/pre>/g;
    if (html.match(codeBlockRegex)) {
        // Already in code blocks, just format it properly
        return html.replace(codeBlockRegex, (match, diagramCode) => {
            const uniqueId = `mermaid-${props.message.id}-${Date.now()}-${uniqueIdCounter++}`;
            const { mermaid: trimmedCode, explanation } = parseMermaidBlock(diagramCode.trim());
            
            // If streaming, don't try to render incomplete diagrams
            if (isStreaming.value) {
                return `<div class="mermaid-container">
                    <div class="mermaid-loading flex items-center justify-center my-8 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-300 dark:border-gray-600">
                        <div class="flex items-center space-x-3">
                            <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-orange-500"></div>
                            <span class="text-sm text-gray-600 dark:text-gray-400">Generating diagram...</span>
                        </div>
                    </div>
                </div>`;
            }
            
            // Prepare explanation paragraphs (plain text, no extra styling)
            const escapedExplanation = (explanation || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
            const explanationHtml = escapedExplanation
                .trim()
                .split(/\n{2,}/)
                .map(p => `<p>${p.replace(/\n+/g, ' ')}</p>`) 
                .join('');

            return `<div class=\"mermaid-container relative\"> 
                <button class="mermaid-fullscreen-btn absolute top-2 right-2 z-10 p-2 bg-white dark:bg-gray-800 rounded-md shadow-md hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-300 dark:border-gray-600 opacity-70 hover:opacity-100 transition-opacity" data-mermaid-id="${uniqueId}" title="Enlarge diagram">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path>
                    </svg>
                </button>
                <div class="mermaid-loading flex items-center justify-center my-8 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-300 dark:border-gray-600">
                    <div class="flex items-center space-x-3">
                        <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-orange-500"></div>
                        <span class="text-sm text-gray-600 dark:text-gray-400">Rendering diagram...</span>
                    </div>
                </div>
                <div class=\"mermaid my-8 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-300 dark:border-gray-600 overflow-x-auto\" id=\"${uniqueId}\" style=\"display: none;\">${trimmedCode}</div>
                ${explanationHtml ? `${explanationHtml}` : ''}
            </div>`;
        });
    }
    
    // Look for standalone Mermaid syntax (flowchart/graph followed by node definitions)
    // Use a more comprehensive regex that captures the full diagram (greedy match)
    // The key is matching everything up to paragraph breaks, double newlines, or end of content
    const standaloneMermaidRegex = /(<p>|<br>|<br\s*\/>|\n)?(flowchart\s+(?:TD|LR|TB|BT)\s*;?|graph\s+(?:TD|LR|TB|BT)\s*;?)([\s\S]+)(?=(?:\n\n)|(?:<p[^>]*>)|(?:<\/p>)|<\/div>|$)/g;
    
    return html.replace(standaloneMermaidRegex, (fullMatch, before, graphDecl, diagramContent, offset) => {
        // Check if this match is already inside a mermaid-container (to avoid double-processing)
        const beforeMatch = html.substring(0, offset);
        const lastContainer = beforeMatch.lastIndexOf('mermaid-container');
        const lastClosingDiv = beforeMatch.lastIndexOf('</div>', lastContainer);
        const isAlreadyProcessed = lastContainer !== -1 && (lastClosingDiv === -1 || lastClosingDiv < lastContainer);
        
        if (isAlreadyProcessed) {
            return fullMatch; // Return original, don't process again
        }
        
        const uniqueId = `mermaid-${props.message.id}-${Date.now()}-${uniqueIdCounter++}`;
        // Combine the graph declaration with content and parse
        const parsed = parseMermaidBlock((graphDecl + diagramContent).trim());
        const cleanCode = parsed.mermaid;
        const explanation = parsed.explanation;
        
        // If streaming, don't try to render incomplete diagrams
        if (isStreaming.value) {
            return `<div class="mermaid-container">
                <div class="mermaid-loading flex items-center justify-center my-8 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-300 dark:border-gray-600">
                    <div class="flex items-center space-x-3">
                        <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-orange-500"></div>
                        <span class="text-sm text-gray-600 dark:text-gray-400">Generating diagram...</span>
                    </div>
                </div>
            </div>`;
        }
        
        // Prepare explanation paragraphs (plain text, no extra styling)
        const escapedExplanation = (explanation || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        const explanationHtml = escapedExplanation
            .trim()
            .split(/\n{2,}/)
            .map(p => `<p>${p.replace(/\n+/g, ' ')}</p>`) 
            .join('');

        return `<div class=\"mermaid-container relative\"> 
            <button class="mermaid-fullscreen-btn absolute top-2 right-2 z-10 p-2 bg-white dark:bg-gray-800 rounded-md shadow-md hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-300 dark:border-gray-600 opacity-70 hover:opacity-100 transition-opacity" data-mermaid-id="${uniqueId}" title="Enlarge diagram">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path>
                </svg>
            </button>
            <div class="mermaid-loading flex items-center justify-center my-8 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-300 dark:border-gray-600">
                <div class="flex items-center space-x-3">
                    <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-orange-500"></div>
                    <span class="text-sm text-gray-600 dark:text-gray-400">Rendering diagram...</span>
                </div>
            </div>
            <div class=\"mermaid my-8 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-300 dark:border-gray-600 overflow-x-auto\" id=\"${uniqueId}\" style=\"display: none;\">${cleanCode}</div>
            ${explanationHtml ? `${explanationHtml}` : ''}
        </div>`;
    });
};

// Render Mermaid diagrams after content is mounted
const renderMermaidDiagrams = async () => {
    await nextTick();
    
    if (!proseRef.value) return;
    
    // Don't render diagrams while streaming - wait for complete content
    if (isStreaming.value) return;
    
    // Find all .mermaid divs that haven't been rendered yet
    const mermaidDivs = proseRef.value.querySelectorAll<HTMLElement>('.mermaid:not(.mermaid-rendered)');
    
    if (mermaidDivs.length === 0) return;
    
    // Emit event to notify ChatLayout that Mermaid is rendering
    window.dispatchEvent(new CustomEvent('mermaid-rendering-start'));
    
    // Get the chat container to preserve scroll position
    const chatContainer = document.querySelector('.chat-scrollbar') as HTMLElement;
    let scrollTop = 0;
    let scrollHeight = 0;
    let isNearBottom = false;
    
    if (chatContainer) {
        scrollTop = chatContainer.scrollTop;
        scrollHeight = chatContainer.scrollHeight;
        const clientHeight = chatContainer.clientHeight;
        // Check if user is near bottom (within 200px)
        isNearBottom = (scrollHeight - scrollTop - clientHeight) < 200;
    }
    
    // Hide all loading indicators and show mermaid divs
    // First, set a minimum height to prevent layout shift
    mermaidDivs.forEach(mermaidDiv => {
        const container = mermaidDiv.closest('.mermaid-container') as HTMLElement;
        if (container) {
            const loadingDiv = container.querySelector('.mermaid-loading') as HTMLElement;
            if (loadingDiv) {
                // Set minimum height based on loading div before hiding it
                const minHeight = loadingDiv.offsetHeight || 200;
                container.style.minHeight = `${minHeight}px`;
                loadingDiv.style.display = 'none';
            }
            mermaidDiv.style.display = 'block';
            // Set initial min-height for mermaid div
            mermaidDiv.style.minHeight = '200px';
        }
    });
    
    // Preserve scroll position during rendering
    const restoreScroll = () => {
        if (chatContainer) {
            if (isNearBottom) {
                // If near bottom, scroll to bottom after render
                requestAnimationFrame(() => {
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                });
            } else {
                // Otherwise, maintain relative scroll position
                const newScrollHeight = chatContainer.scrollHeight;
                const heightDiff = newScrollHeight - scrollHeight;
                if (heightDiff > 0) {
                    chatContainer.scrollTop = scrollTop + heightDiff;
                }
            }
        }
    };
    
    try {
        // Use mermaid.run() which automatically detects .mermaid divs and renders them
        await mermaid.run();
        
        // Wait for next frame to ensure rendering is complete
        await new Promise(resolve => requestAnimationFrame(resolve));
        
        // Remove min-height constraints now that rendering is complete
        mermaidDivs.forEach(mermaidDiv => {
            const container = mermaidDiv.closest('.mermaid-container') as HTMLElement;
            if (container) {
                container.style.minHeight = '';
                mermaidDiv.style.minHeight = '';
            }
        });
        
        // Restore scroll position
        restoreScroll();
        
        // Mark as rendered to avoid re-rendering
        mermaidDivs.forEach(div => {
            div.classList.add('mermaid-rendered');
        });
        
        // Setup fullscreen buttons after rendering
        await nextTick();
        setupFullscreenButtons();
        
        // Emit event to notify ChatLayout that Mermaid rendering is complete
        window.dispatchEvent(new CustomEvent('mermaid-rendering-complete'));
        
        console.log(`✅ Rendered ${mermaidDivs.length} Mermaid diagram(s)`);
    } catch (error) {
        console.error('❌ Error rendering Mermaid diagrams:', error);
        // Show error message to user
        mermaidDivs.forEach(mermaidDiv => {
            const container = mermaidDiv.closest('.mermaid-container') as HTMLElement;
            if (container) {
                container.style.minHeight = '';
                mermaidDiv.style.minHeight = '';
                const loadingDiv = container.querySelector('.mermaid-loading') as HTMLElement;
                if (loadingDiv) {
                    loadingDiv.innerHTML = '<span class="text-sm text-red-500 dark:text-red-400">Error rendering diagram</span>';
                    loadingDiv.style.display = 'block';
                }
            }
        });
        restoreScroll();
        
        // Emit event even on error
        window.dispatchEvent(new CustomEvent('mermaid-rendering-complete'));
    }
};

// Handle fullscreen for Mermaid diagrams
const openMermaidFullscreen = (mermaidId: string) => {
    const mermaidDiv = document.getElementById(mermaidId);
    if (!mermaidDiv) return;
    
    // Create fullscreen overlay
    const overlay = document.createElement('div');
    overlay.className = 'mermaid-fullscreen-overlay fixed inset-0 z-50 bg-black bg-opacity-90 flex items-center justify-center p-8';
    overlay.innerHTML = `
        <div class="relative w-full h-full flex items-center justify-center">
            <button class="mermaid-close-btn absolute top-4 right-4 z-60 p-3 bg-white dark:bg-gray-800 rounded-md shadow-lg hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300" title="Close">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
            <div class="mermaid-fullscreen-content w-full h-full overflow-auto p-8 bg-white dark:bg-gray-900 rounded-lg" style="max-width: 95vw; max-height: 95vh;">
                <div class="mermaid-fullscreen-inner"></div>
            </div>
        </div>
    `;
    
    // Clone the mermaid SVG content
    const mermaidSvg = mermaidDiv.querySelector('svg');
    if (mermaidSvg) {
        const clone = mermaidSvg.cloneNode(true) as SVGElement;
        clone.style.maxWidth = '100%';
        clone.style.height = 'auto';
        clone.style.width = 'auto';
        
        const innerDiv = overlay.querySelector('.mermaid-fullscreen-inner');
        if (innerDiv) {
            innerDiv.appendChild(clone);
        }
    }
    
    // Close button handler
    const closeBtn = overlay.querySelector('.mermaid-close-btn');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            document.body.removeChild(overlay);
            document.body.style.overflow = '';
        });
    }
    
    // Close on overlay click (but not on content click)
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            document.body.removeChild(overlay);
            document.body.style.overflow = '';
        }
    });
    
    // Close on Escape key
    const handleEscape = (e: KeyboardEvent) => {
        if (e.key === 'Escape' && document.body.contains(overlay)) {
            document.body.removeChild(overlay);
            document.body.style.overflow = '';
            document.removeEventListener('keydown', handleEscape);
        }
    };
    document.addEventListener('keydown', handleEscape);
    
    // Append to body and prevent scrolling
    document.body.appendChild(overlay);
    document.body.style.overflow = 'hidden';
};

// Setup fullscreen button handlers after diagrams are rendered
const setupFullscreenButtons = () => {
    if (!proseRef.value) return;
    
    // Remove old event listeners by replacing buttons
    const buttons = proseRef.value.querySelectorAll('.mermaid-fullscreen-btn');
    buttons.forEach(btn => {
        const mermaidId = btn.getAttribute('data-mermaid-id');
        if (mermaidId) {
            btn.addEventListener('click', () => openMermaidFullscreen(mermaidId));
            // Ensure button is visible
            const container = btn.closest('.mermaid-container');
            if (container) {
                container.classList.add('group');
            }
        }
    });
};

// Initialize Mermaid on mount
onMounted(() => {
    // Detect if we're on mobile
    const isMobile = window.innerWidth <= 768;
    
    mermaid.initialize({ 
        startOnLoad: false,
        theme: 'default',
        securityLevel: 'loose',
        flowchart: {
            useMaxWidth: isMobile, // Enable on mobile to prevent overflow
            htmlLabels: true,
            fontSize: 14,
            curve: 'basis'
        },
        fontSize: 14,
        fontFamily: 'Arial, sans-serif'
    });
    
    // Render diagrams on mount
    renderMermaidDiagrams().then(async () => {
        // Setup fullscreen buttons after rendering
        await nextTick();
        setupFullscreenButtons();
    });
});

// Debounce Mermaid rendering to avoid multiple renders
let mermaidRenderTimeout: ReturnType<typeof setTimeout> | null = null;

// Watch for content changes and re-render diagrams when streaming completes
watch([() => props.message.content, () => props.message.streamingContent], async () => {
    // Wait a bit after streaming to ensure content is complete
    if (isStreaming.value) {
        return;
    }
    
    // Clear any pending render
    if (mermaidRenderTimeout) {
        clearTimeout(mermaidRenderTimeout);
    }
    
    // Debounce rendering to avoid rapid re-renders
    mermaidRenderTimeout = setTimeout(async () => {
        await nextTick();
        await renderMermaidDiagrams();
        await nextTick();
        setupFullscreenButtons();
    }, 300); // Wait 300ms after content stops changing
}, { immediate: false });

// Also watch for when streaming state changes from true to false
watch(() => isStreaming.value, async (isCurrentlyStreaming, wasStreaming) => {
    // When streaming completes (was streaming, now not streaming)
    if (!isCurrentlyStreaming && wasStreaming) {
        // Clear any pending render
        if (mermaidRenderTimeout) {
            clearTimeout(mermaidRenderTimeout);
        }
        
        await nextTick();
        // Small delay to ensure DOM is updated, then render
        mermaidRenderTimeout = setTimeout(async () => {
            await renderMermaidDiagrams();
            await nextTick();
            setupFullscreenButtons();
        }, 300);
    }
}, { immediate: false });

// Smart auto-scroll: only scroll if user is near the bottom
const shouldAutoScroll = () => {
    const chatContainer = document.querySelector('.chat-scrollbar');
    if (!chatContainer) return false;
    
    const scrollTop = chatContainer.scrollTop;
    const scrollHeight = chatContainer.scrollHeight;
    const clientHeight = chatContainer.clientHeight;
    
    // Only auto-scroll if user is within 100px of the bottom
    return (scrollHeight - scrollTop - clientHeight) < 100;
};

// Note: Auto-scrolling during streaming is handled by ChatLayout.vue
// We don't need to handle scroll here to avoid conflicts and jitter
</script>
<template>
    <div class="group flex items-start space-x-4 py-4" :data-message-id="message.id">
        <!-- Avatar -->
        <div class="flex-shrink-0">
            <div v-if="isUser" 
                 class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <User class="w-4 h-4 text-white" />
            </div>
            <div v-else 
                 class="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                <Bot class="w-4 h-4 text-white" />
            </div>
        </div>

        <div class="flex-1 min-w-0">
            <div class="flex items-center space-x-2 mb-1">
                <span class="text-sm font-medium text-gray-900 dark:text-white">
                    {{ isUser ? 'You' : 'OposChat' }}
                </span>
                <span class="text-xs text-gray-500">
                    {{ message.timestamp }}
                </span>
                <!-- Streaming indicator -->
                <span v-if="isStreaming" class="text-xs text-orange-500 animate-pulse">
                    {{ hasStreamingContent ? 'typing...' : 'thinking...' }}
                </span>
                <!-- Auto-scroll indicator -->
                <span v-if="isStreaming && !shouldAutoScroll()" class="text-xs text-blue-500 ml-2">
                    (scroll to see live updates)
                </span>
            </div>
            
            <div ref="proseRef" class="prose prose-sm max-w-none text-gray-900 dark:text-white w-full overflow-hidden">
                <!-- Streaming content with real-time formatting -->
                <div v-if="isStreaming && hasStreamingContent" 
                     class="streaming-content"
                 v-html="formatContent(message.streamingContent, false)">
                </div>
                
                <!-- Regular content with formatting -->
                <div v-else class="message-content" v-html="formatContent(message.content)">
                </div>
                
                <!-- Streaming cursor -->
                <span v-if="isStreaming" class="inline-block w-0.5 h-4 bg-orange-500 animate-pulse ml-1"></span>
            </div>
            <!-- Message Actions for Assistant -->
            <div v-if="!isUser" class="flex items-center space-x-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                <!-- Stop streaming button -->
                <Button v-if="isStreaming" 
                        @click="stopStreaming" 
                        size="sm" 
                        variant="ghost" 
                        class="h-8 px-2 text-red-500 hover:text-red-700">
                    <Square class="w-3 h-3 mr-1" />
                    Stop
                </Button>
                
                <!-- Copy button -->
                <Button @click="copyMessage" 
                        size="sm" 
                        variant="ghost" 
                        class="h-8 px-2 text-gray-500 hover:text-gray-700">
                    <Copy class="w-3 h-3 mr-1" />
                    Copy
                </Button>
                
                <!-- Feedback buttons (only show when not streaming) -->
                <Button v-if="!isStreaming" 
                        size="sm" 
                        variant="ghost" 
                        class="h-8 px-2 text-gray-500 hover:text-gray-700">
                    <ThumbsUp class="w-3 h-3" />
                </Button>
                <Button v-if="!isStreaming" 
                        size="sm" 
                        variant="ghost" 
                        class="h-8 px-2 text-gray-500 hover:text-gray-700">
                    <ThumbsDown class="w-3 h-3" />
                </Button>
            </div>
            
            <!-- Message Actions for User -->
            <div v-if="isUser" class="flex items-center space-x-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                <!-- Copy button -->
                <Button @click="copyMessage" 
                        size="sm" 
                        variant="ghost" 
                        class="h-8 px-2 text-gray-500 hover:text-gray-700">
                    <Copy class="w-3 h-3 mr-1" />
                    Copy
                </Button>
            </div>
        </div>
    </div>
</template>

<style scoped>
.streaming-content {
    line-height: 1.6;
}

.streaming-content :deep(pre) {
    margin: 1rem 0;
    padding: 1rem;
    background-color: rgb(243 244 246);
    border-radius: 0.5rem;
    overflow-x: auto;
}

.dark .streaming-content :deep(pre) {
    background-color: rgb(31 41 55);
}

.streaming-content :deep(code) {
    font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
    font-size: 0.875rem;
}

.streaming-content :deep(h1) {
    font-size: 1.5rem;
    font-weight: 700;
    margin-top: 1rem;
    margin-bottom: 0.5rem;
}

.streaming-content :deep(h2) {
    font-size: 1.25rem;
    font-weight: 600;
    margin-top: 1rem;
    margin-bottom: 0.5rem;
}

.streaming-content :deep(h3) {
    font-size: 1.125rem;
    font-weight: 600;
    margin-top: 1rem;
    margin-bottom: 0.5rem;
}

.streaming-content :deep(ul) {
    margin: 0.5rem 0;
    padding-left: 1.5rem;
}

.streaming-content :deep(li) {
    margin: 0.25rem 0;
}

.streaming-content :deep(strong) {
    font-weight: 600;
}

.streaming-content :deep(em) {
    font-style: italic;
}

.message-content {
    line-height: 1.6;
}

/* Heading styles for clearer structure in long plans */
.streaming-content :deep(h1), .message-content :deep(h1) {
    font-size: 1.5rem;
    font-weight: 700;
    margin-top: 1rem;
    margin-bottom: 0.5rem;
}
.streaming-content :deep(h2), .message-content :deep(h2) {
    font-size: 1.25rem;
    font-weight: 600;
    margin-top: 0.9rem;
    margin-bottom: 0.4rem;
}
.streaming-content :deep(h3), .message-content :deep(h3) {
    font-size: 1.1rem;
    font-weight: 600;
    margin-top: 0.7rem;
    margin-bottom: 0.3rem;
}

/* Ensure table layout is full width */
.streaming-content table,
.message-content table {
    width: 100%;
    table-layout: auto;
}

/* Ensure explanation paragraphs after a diagram wrap like normal chat text */
.message-content :deep(.mermaid ~ p),
.streaming-content :deep(.mermaid ~ p) {
    white-space: normal;
    overflow-wrap: anywhere;
    word-break: break-word;
    font-family: 'Instrument Sans', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Noto Sans, Ubuntu, Cantarell, Helvetica Neue, Arial, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
    font-weight: 400;
}

/* Mermaid: improve arrow visibility in dark mode */
.dark .streaming-content :deep(.mermaid .edgePath path),
.dark .message-content :deep(.mermaid .edgePath path) {
    stroke: #ffffff !important;
}
.dark .streaming-content :deep(.mermaid .flowchart-link),
.dark .message-content :deep(.mermaid .flowchart-link) {
    stroke: #ffffff !important;
}
.dark .streaming-content :deep(.mermaid marker path),
.dark .message-content :deep(.mermaid marker path) {
    fill: #ffffff !important;
    stroke: #ffffff !important;
}



/* Ensure tables in messages take full width */
.streaming-content table,
.message-content table {
    width: 100%;
    table-layout: auto;
}

/* Mermaid diagram styling for mobile */
.message-content :deep(.mermaid-container),
.streaming-content :deep(.mermaid-container) {
    width: 100%;
    max-width: 100%;
    overflow: hidden;
}

.message-content :deep(.mermaid),
.streaming-content :deep(.mermaid) {
    width: 100%;
    max-width: 100%;
    overflow-x: auto;
    overflow-y: visible;
    /* Prevent horizontal scroll on mobile */
    -webkit-overflow-scrolling: touch;
}

/* Mobile-specific fixes for Mermaid diagrams */
@media (max-width: 768px) {
    .message-content :deep(.mermaid-container),
    .streaming-content :deep(.mermaid-container) {
        margin-left: -0.5rem !important;
        margin-right: -0.5rem !important;
        padding-left: 0.5rem !important;
        padding-right: 0.5rem !important;
    }
    
    .message-content :deep(.mermaid),
    .streaming-content :deep(.mermaid) {
        margin-left: 0 !important;
        margin-right: 0 !important;
        padding: 0 !important;
        /* Ensure diagram doesn't cause horizontal overflow */
        max-width: calc(100vw - 2rem);
        width: 100%;
    }
    
    .message-content :deep(.mermaid svg),
    .streaming-content :deep(.mermaid svg) {
        max-width: 100% !important;
        height: auto !important;
    }
    
    /* Prevent prose from causing overflow */
    .prose {
        max-width: 100%;
        overflow: hidden;
    }
}

/* Fullscreen button styles */
.message-content :deep(.mermaid-container.group:hover .mermaid-fullscreen-btn),
.streaming-content :deep(.mermaid-container.group:hover .mermaid-fullscreen-btn) {
    opacity: 1 !important;
}

.message-content :deep(.mermaid-fullscreen-btn),
.streaming-content :deep(.mermaid-fullscreen-btn) {
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Fullscreen overlay styles */
:deep(.mermaid-fullscreen-overlay) {
    backdrop-filter: blur(4px);
}

:deep(.mermaid-fullscreen-content) {
    display: flex;
    align-items: center;
    justify-content: center;
}

:deep(.mermaid-fullscreen-inner) {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
}

:deep(.mermaid-fullscreen-inner svg) {
    max-width: 100%;
    max-height: 100%;
}
</style>